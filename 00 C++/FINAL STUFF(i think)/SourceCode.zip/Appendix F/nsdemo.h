// This file defines a namespace named demo. 
// In the demo namespace a class named NsDemo
// is declared, and an instance of the class
// named testObject is defined.

namespace demo
{
   class NsDemo
   {
      public:
         int x, y, z;
   };

   NsDemo testObject;
}